-- MySQL dump 10.13  Distrib 8.0.28, for Linux (x86_64)
--
-- Host: localhost    Database: edukus_db
-- ------------------------------------------------------
-- Server version	8.0.28

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `DATABASECHANGELOG`
--

DROP TABLE IF EXISTS `DATABASECHANGELOG`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `DATABASECHANGELOG` (
  `ID` varchar(255) NOT NULL,
  `AUTHOR` varchar(255) NOT NULL,
  `FILENAME` varchar(255) NOT NULL,
  `DATEEXECUTED` datetime NOT NULL,
  `ORDEREXECUTED` int NOT NULL,
  `EXECTYPE` varchar(10) NOT NULL,
  `MD5SUM` varchar(35) DEFAULT NULL,
  `DESCRIPTION` varchar(255) DEFAULT NULL,
  `COMMENTS` varchar(255) DEFAULT NULL,
  `TAG` varchar(255) DEFAULT NULL,
  `LIQUIBASE` varchar(20) DEFAULT NULL,
  `CONTEXTS` varchar(255) DEFAULT NULL,
  `LABELS` varchar(255) DEFAULT NULL,
  `DEPLOYMENT_ID` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DATABASECHANGELOG`
--

LOCK TABLES `DATABASECHANGELOG` WRITE;
/*!40000 ALTER TABLE `DATABASECHANGELOG` DISABLE KEYS */;
INSERT INTO `DATABASECHANGELOG` VALUES ('raw','includeAll','static/scripts/0.0.0_create_default_schema.sql','2022-02-01 19:43:19',1,'EXECUTED','8:b74eeeba635846a6fc1256c8b9949688','sql','',NULL,'4.3.1',NULL,NULL,'3744598982'),('raw','includeAll','static/scripts/0.0.1_init_database.sql','2022-02-01 19:43:19',2,'EXECUTED','8:2a03d913d7e1d1d346e979faea1c5b7a','sql','',NULL,'4.3.1',NULL,NULL,'3744598982'),('raw','includeAll','static/scripts/0.0.2_create_article_category_table.sql','2022-02-01 19:43:20',3,'EXECUTED','8:a25bc89e1220aa6fcc02953773cb3e99','sql','',NULL,'4.3.1',NULL,NULL,'3744598982'),('raw','includeAll','static/scripts/0.0.3_create_article_table.sql','2022-02-01 19:43:20',4,'EXECUTED','8:1cfc15a5b27c96da2a2c23a95369e343','sql','',NULL,'4.3.1',NULL,NULL,'3744598982'),('raw','includeAll','static/scripts/0.0.4_create_article_content_table.sql','2022-02-01 19:43:20',5,'EXECUTED','8:789dabf651b973978d623bd765243bb4','sql','',NULL,'4.3.1',NULL,NULL,'3744598982'),('raw','includeAll','static/scripts/0.0.5_insert_role_admin.sql','2022-02-01 19:43:20',6,'EXECUTED','8:874acbc3e8136bc39db00a74c808f94f','sql','',NULL,'4.3.1',NULL,NULL,'3744598982'),('raw','includeAll','static/scripts/0.0.6_create_medicine_table.sql','2022-02-01 19:43:20',7,'EXECUTED','8:f2cb7a54329391443e612da1ce29bc77','sql','',NULL,'4.3.1',NULL,NULL,'3744598982'),('raw','includeAll','static/scripts/0.0.7_create_medicine_time_table.sql','2022-02-01 19:43:20',8,'EXECUTED','8:7df7e3539b0966a52bf18fc8ead73f9d','sql','',NULL,'4.3.1',NULL,NULL,'3744598982'),('raw','includeAll','static/scripts/0.0.8_create_measure_sub_type_table.sql','2022-02-01 19:43:20',9,'EXECUTED','8:a57cb87c0357b9fc90a8f21e5a600a9b','sql','',NULL,'4.3.1',NULL,NULL,'3744598982'),('raw','includeAll','static/scripts/0.0.9_init_measure_sub_type_table.sql','2022-02-01 19:43:20',10,'EXECUTED','8:fc02693481909ae8d7b1f73a9ec07109','sql','',NULL,'4.3.1',NULL,NULL,'3744598982'),('raw','includeAll','static/scripts/0.0.10_add_foreign_key_measure_sub_type_to_measure_table.sql','2022-02-01 19:43:20',11,'EXECUTED','8:0f1098f1108adaba46d6da996de718f9','sql','',NULL,'4.3.1',NULL,NULL,'3744598982'),('raw','includeAll','static/scripts/0.0.11_update_measure_type_add_min_max_tension.sql','2022-02-01 19:43:20',12,'EXECUTED','8:73d563b7689d79ae1c03f9401b9dc733','sql','',NULL,'4.3.1',NULL,NULL,'3744598982'),('raw','includeAll','static/scripts/0.0.12_create_appointment_table.sql','2022-02-01 19:43:20',13,'EXECUTED','8:205dd7731e2f68f6f89d4d562ff0d479','sql','',NULL,'4.3.1',NULL,NULL,'3744598982'),('raw','includeAll','static/scripts/0.0.13_update_medicine_time_add_notification_column.sql','2022-02-01 19:43:20',14,'EXECUTED','8:67e5deb5319dbdd92ea3e2a7697b2fcc','sql','',NULL,'4.3.1',NULL,NULL,'3744598982'),('raw','includeAll','static/scripts/0.0.14_create_notification_table.sql','2022-02-01 19:43:20',15,'EXECUTED','8:594217cfb1eade037e84415ed64f5285','sql','',NULL,'4.3.1',NULL,NULL,'3744598982');
/*!40000 ALTER TABLE `DATABASECHANGELOG` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `DATABASECHANGELOGLOCK`
--

DROP TABLE IF EXISTS `DATABASECHANGELOGLOCK`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `DATABASECHANGELOGLOCK` (
  `ID` int NOT NULL,
  `LOCKED` bit(1) NOT NULL,
  `LOCKGRANTED` datetime DEFAULT NULL,
  `LOCKEDBY` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DATABASECHANGELOGLOCK`
--

LOCK TABLES `DATABASECHANGELOGLOCK` WRITE;
/*!40000 ALTER TABLE `DATABASECHANGELOGLOCK` DISABLE KEYS */;
INSERT INTO `DATABASECHANGELOGLOCK` VALUES (1,_binary '\0',NULL,NULL);
/*!40000 ALTER TABLE `DATABASECHANGELOGLOCK` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `app_setting`
--

DROP TABLE IF EXISTS `app_setting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `app_setting` (
  `id` bigint NOT NULL,
  `label` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `app_setting`
--

LOCK TABLES `app_setting` WRITE;
/*!40000 ALTER TABLE `app_setting` DISABLE KEYS */;
INSERT INTO `app_setting` VALUES (1,'global');
/*!40000 ALTER TABLE `app_setting` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `appointment`
--

DROP TABLE IF EXISTS `appointment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `appointment` (
  `id` bigint NOT NULL,
  `service` varchar(255) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `note` varchar(255) DEFAULT NULL,
  `date` datetime(6) NOT NULL,
  `email` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_appointment_email_user_email` (`email`),
  CONSTRAINT `fk_appointment_email_user_email` FOREIGN KEY (`email`) REFERENCES `user` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `appointment`
--

LOCK TABLES `appointment` WRITE;
/*!40000 ALTER TABLE `appointment` DISABLE KEYS */;
/*!40000 ALTER TABLE `appointment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `article`
--

DROP TABLE IF EXISTS `article`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `article` (
  `id` bigint NOT NULL,
  `author` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `url_to_image` varchar(255) NOT NULL,
  `published_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `email` varchar(255) NOT NULL,
  `category` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_article_email_user_email` (`email`),
  KEY `fk_article_category_article_category_code` (`category`),
  CONSTRAINT `fk_article_category_article_category_code` FOREIGN KEY (`category`) REFERENCES `article_category` (`code`),
  CONSTRAINT `fk_article_email_user_email` FOREIGN KEY (`email`) REFERENCES `user` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `article`
--

LOCK TABLES `article` WRITE;
/*!40000 ALTER TABLE `article` DISABLE KEYS */;
/*!40000 ALTER TABLE `article` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `article_category`
--

DROP TABLE IF EXISTS `article_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `article_category` (
  `id` bigint NOT NULL,
  `code` varchar(255) NOT NULL,
  `label` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`),
  KEY `FK_article_category_article` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `article_category`
--

LOCK TABLES `article_category` WRITE;
/*!40000 ALTER TABLE `article_category` DISABLE KEYS */;
INSERT INTO `article_category` VALUES (1,'ma','Medical articles'),(2,'pa','Practical advice'),(3,'npa','Nutrition and physical activity');
/*!40000 ALTER TABLE `article_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `article_content`
--

DROP TABLE IF EXISTS `article_content`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `article_content` (
  `id` bigint NOT NULL,
  `content` text NOT NULL,
  PRIMARY KEY (`id`),
  CONSTRAINT `fk_article_id_user_id` FOREIGN KEY (`id`) REFERENCES `article` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `article_content`
--

LOCK TABLES `article_content` WRITE;
/*!40000 ALTER TABLE `article_content` DISABLE KEYS */;
/*!40000 ALTER TABLE `article_content` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `association`
--

DROP TABLE IF EXISTS `association`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `association` (
  `id` bigint NOT NULL,
  `status` varchar(255) DEFAULT NULL,
  `doctor` varchar(255) DEFAULT NULL,
  `patient` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKis7ylkjp4aopwmn9w1h1iru84` (`patient`),
  KEY `FKlmfpkpa9ut1bg017ge4u7puig` (`doctor`),
  CONSTRAINT `FKis7ylkjp4aopwmn9w1h1iru84` FOREIGN KEY (`patient`) REFERENCES `user` (`email`),
  CONSTRAINT `FKlmfpkpa9ut1bg017ge4u7puig` FOREIGN KEY (`doctor`) REFERENCES `user` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `association`
--

LOCK TABLES `association` WRITE;
/*!40000 ALTER TABLE `association` DISABLE KEYS */;
/*!40000 ALTER TABLE `association` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hibernate_sequence`
--

DROP TABLE IF EXISTS `hibernate_sequence`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `hibernate_sequence` (
  `next_val` bigint DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hibernate_sequence`
--

LOCK TABLES `hibernate_sequence` WRITE;
/*!40000 ALTER TABLE `hibernate_sequence` DISABLE KEYS */;
INSERT INTO `hibernate_sequence` VALUES (2);
/*!40000 ALTER TABLE `hibernate_sequence` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `measure`
--

DROP TABLE IF EXISTS `measure`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `measure` (
  `id` bigint NOT NULL,
  `date_time` datetime(6) NOT NULL,
  `prandial` varchar(255) DEFAULT NULL,
  `reason` varchar(255) DEFAULT NULL,
  `value` double NOT NULL,
  `measure_type_id` bigint NOT NULL,
  `email` varchar(255) NOT NULL,
  `measure_sub_type_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK2merkfyt7udl8y3g0hsip3rdm` (`measure_type_id`),
  KEY `FK2y5trxxt05w554tudhc7k0fnf` (`email`),
  KEY `FK2y5trdssd5wfdfsudhc7k0fnf` (`prandial`),
  KEY `FK_measure_measure_sub_type_id_measure_sub_type_id` (`measure_sub_type_id`),
  CONSTRAINT `FK2merkfyt7udl8y3g0hsip3rdm` FOREIGN KEY (`measure_type_id`) REFERENCES `measure_type` (`id`),
  CONSTRAINT `FK2y5trdssd5wfdfsudhc7k0fnf` FOREIGN KEY (`prandial`) REFERENCES `st_prandial` (`code`),
  CONSTRAINT `FK2y5trxxt05w554tudhc7k0fnf` FOREIGN KEY (`email`) REFERENCES `user` (`email`),
  CONSTRAINT `FK_measure_measure_sub_type_id_measure_sub_type_id` FOREIGN KEY (`measure_sub_type_id`) REFERENCES `measure_sub_type` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `measure`
--

LOCK TABLES `measure` WRITE;
/*!40000 ALTER TABLE `measure` DISABLE KEYS */;
/*!40000 ALTER TABLE `measure` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `measure_sub_type`
--

DROP TABLE IF EXISTS `measure_sub_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `measure_sub_type` (
  `id` bigint NOT NULL,
  `code` varchar(255) NOT NULL,
  `label` varchar(255) NOT NULL,
  `unit` varchar(255) NOT NULL,
  `measure_type_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_measure_sub_type_id_measure_type_id` (`measure_type_id`),
  CONSTRAINT `FK_measure_sub_type_id_measure_type_id` FOREIGN KEY (`measure_type_id`) REFERENCES `measure_type` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `measure_sub_type`
--

LOCK TABLES `measure_sub_type` WRITE;
/*!40000 ALTER TABLE `measure_sub_type` DISABLE KEYS */;
INSERT INTO `measure_sub_type` VALUES (1,'height','height','m',4),(2,'weight','weight','kg',4),(3,'systolic','systolic','mmHg',3),(4,'diastolic','diastolic','mmHg',3);
/*!40000 ALTER TABLE `measure_sub_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `measure_type`
--

DROP TABLE IF EXISTS `measure_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `measure_type` (
  `id` bigint NOT NULL,
  `code` varchar(255) NOT NULL,
  `label` varchar(255) NOT NULL,
  `max` float DEFAULT NULL,
  `max_ref_post_prandial` float DEFAULT NULL,
  `max_ref_pre_prandial` float DEFAULT NULL,
  `min` float DEFAULT NULL,
  `min_ref_post_prandial` float DEFAULT NULL,
  `min_ref_pre_prandial` float DEFAULT NULL,
  `unit` varchar(255) NOT NULL,
  `min_diastolic` float DEFAULT NULL,
  `max_diastolic` float DEFAULT NULL,
  `min_systolic` float DEFAULT NULL,
  `max_systolic` float DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `measure_type`
--

LOCK TABLES `measure_type` WRITE;
/*!40000 ALTER TABLE `measure_type` DISABLE KEYS */;
INSERT INTO `measure_type` VALUES (1,'glc','glucose sanguin',NULL,1.6,1.2,NULL,0.8,0.8,'g/l',NULL,NULL,NULL,NULL),(2,'hb1ac','HB1Ac',6.5,NULL,NULL,NULL,NULL,NULL,'%',NULL,NULL,NULL,NULL),(3,'tension','Tension artérielle',NULL,NULL,NULL,NULL,NULL,NULL,'mmHg',70,90,100,140),(4,'imc','Indice de la masse corporelle',25,NULL,NULL,18,NULL,NULL,'kg/m²',NULL,NULL,NULL,NULL),(5,'ldl','LDL',1,NULL,NULL,NULL,NULL,NULL,'g/l',NULL,NULL,NULL,NULL),(6,'hdl','HDL',NULL,NULL,NULL,0.5,NULL,NULL,'g/l',NULL,NULL,NULL,NULL),(7,'trig','Triglycerides',1.5,NULL,NULL,NULL,NULL,NULL,'g/l',NULL,NULL,NULL,NULL),(8,'prot','Protéinurie',30,NULL,NULL,NULL,NULL,NULL,'mg/24h',NULL,NULL,NULL,NULL),(9,'creatinine','Créatinine',12,NULL,NULL,5,NULL,NULL,'mg/l',NULL,NULL,NULL,NULL),(10,'clairance','Clairance',NULL,NULL,NULL,15,NULL,NULL,'ml/mn',NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `measure_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `medicine`
--

DROP TABLE IF EXISTS `medicine`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `medicine` (
  `id` bigint NOT NULL,
  `label` varchar(255) NOT NULL,
  `qte` double NOT NULL,
  `unit` varchar(255) NOT NULL,
  `prandial` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK2y5trdsr44wfdfsudhc7k0fnf` (`prandial`),
  KEY `fk_medicine_email_user_email` (`email`),
  CONSTRAINT `FK2y5trdsr44wfdfsudhc7k0fnf` FOREIGN KEY (`prandial`) REFERENCES `st_prandial` (`code`),
  CONSTRAINT `fk_medicine_email_user_email` FOREIGN KEY (`email`) REFERENCES `user` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `medicine`
--

LOCK TABLES `medicine` WRITE;
/*!40000 ALTER TABLE `medicine` DISABLE KEYS */;
/*!40000 ALTER TABLE `medicine` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `medicine_time`
--

DROP TABLE IF EXISTS `medicine_time`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `medicine_time` (
  `id` bigint NOT NULL,
  `time` datetime(6) NOT NULL,
  `notification` bit(1) DEFAULT NULL,
  PRIMARY KEY (`id`,`time`),
  CONSTRAINT `fk_medicine_time_id_medicine_id` FOREIGN KEY (`id`) REFERENCES `medicine` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `medicine_time`
--

LOCK TABLES `medicine_time` WRITE;
/*!40000 ALTER TABLE `medicine_time` DISABLE KEYS */;
/*!40000 ALTER TABLE `medicine_time` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notification`
--

DROP TABLE IF EXISTS `notification`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notification` (
  `id` bigint NOT NULL,
  `time` int NOT NULL,
  `appointment_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_notification_id_appointment_id` (`appointment_id`),
  CONSTRAINT `fk_notification_id_appointment_id` FOREIGN KEY (`appointment_id`) REFERENCES `appointment` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notification`
--

LOCK TABLES `notification` WRITE;
/*!40000 ALTER TABLE `notification` DISABLE KEYS */;
/*!40000 ALTER TABLE `notification` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `registration`
--

DROP TABLE IF EXISTS `registration`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `registration` (
  `id` bigint NOT NULL,
  `registration_challenge` varchar(255) DEFAULT NULL,
  `registration_challenge_date` datetime(6) DEFAULT NULL,
  `token_hash` varchar(255) DEFAULT NULL,
  `email` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK4wl7pkealdw5d1pt6ofg9g77t` (`email`),
  CONSTRAINT `FK4wl7pkealdw5d1pt6ofg9g77t` FOREIGN KEY (`email`) REFERENCES `user` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `registration`
--

LOCK TABLES `registration` WRITE;
/*!40000 ALTER TABLE `registration` DISABLE KEYS */;
INSERT INTO `registration` VALUES (0,'726942','2022-02-05 17:22:45.721042','LwEIaqW6QA1U6_Wd3ZosDUAZV9_AzETJSnCa8XwIr6I','mohamedhak.1107@gmail.com'),(1,'194270','2022-02-05 17:30:23.200125',NULL,'mohamedhak2.1107@gmail.com');
/*!40000 ALTER TABLE `registration` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role`
--

DROP TABLE IF EXISTS `role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `role` (
  `id` bigint NOT NULL,
  `code` varchar(255) NOT NULL,
  `value` varchar(255) NOT NULL,
  `app_setting_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK79qpy0sf2jfbu96r8mi43twkv` (`app_setting_id`),
  CONSTRAINT `FK79qpy0sf2jfbu96r8mi43twkv` FOREIGN KEY (`app_setting_id`) REFERENCES `app_setting` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role`
--

LOCK TABLES `role` WRITE;
/*!40000 ALTER TABLE `role` DISABLE KEYS */;
INSERT INTO `role` VALUES (1,'R01','PATIENT',1),(2,'R02','DOCTOR',1),(3,'R03','ADMIN',1);
/*!40000 ALTER TABLE `role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `st_prandial`
--

DROP TABLE IF EXISTS `st_prandial`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `st_prandial` (
  `id` bigint NOT NULL,
  `code` varchar(255) NOT NULL,
  `label` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`),
  KEY `FK_st_prandial_medicine` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `st_prandial`
--

LOCK TABLES `st_prandial` WRITE;
/*!40000 ALTER TABLE `st_prandial` DISABLE KEYS */;
INSERT INTO `st_prandial` VALUES (1,'prandial','prandial'),(2,'preprandial','preprandial'),(3,'postprandial','postprandial');
/*!40000 ALTER TABLE `st_prandial` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `email` varchar(255) NOT NULL,
  `user_id` varchar(255) NOT NULL,
  `role_id` bigint NOT NULL,
  PRIMARY KEY (`email`),
  UNIQUE KEY `user_id` (`user_id`),
  UNIQUE KEY `UK_a3imlf41l37utmxiquukk8ajc` (`user_id`),
  KEY `FKn82ha3ccdebhokx3a8fgdqeyy` (`role_id`),
  CONSTRAINT `FKn82ha3ccdebhokx3a8fgdqeyy` FOREIGN KEY (`role_id`) REFERENCES `role` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES ('mohamedhak.1107@gmail.com','68c6eb48-f766-4e32-a251-2ed7713eb6f2',2),('mohamedhak2.1107@gmail.com','d4fbb214-c28b-4d29-bfd3-4af083206268',2);
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_file`
--

DROP TABLE IF EXISTS `user_file`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_file` (
  `id` bigint NOT NULL,
  `active` bit(1) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `email` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FKjfyq30ns8axeqbb4nub1346e6` (`email`),
  CONSTRAINT `FKjfyq30ns8axeqbb4nub1346e6` FOREIGN KEY (`email`) REFERENCES `user` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_file`
--

LOCK TABLES `user_file` WRITE;
/*!40000 ALTER TABLE `user_file` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_file` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_profile`
--

DROP TABLE IF EXISTS `user_profile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_profile` (
  `id` bigint NOT NULL,
  `address` varchar(255) DEFAULT NULL,
  `birth_date` datetime(6) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `diabetes_type` varchar(255) DEFAULT NULL,
  `education` varchar(255) DEFAULT NULL,
  `email` varchar(255) NOT NULL,
  `experience` varchar(255) DEFAULT NULL,
  `full_name` varchar(255) DEFAULT NULL,
  `gender` varchar(255) DEFAULT NULL,
  `infection_date` datetime(6) DEFAULT NULL,
  `length` varchar(255) DEFAULT NULL,
  `phone_number` varchar(255) DEFAULT NULL,
  `spoken_languages` varchar(255) DEFAULT NULL,
  `weight` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK97845ptm4fqko9i7n2ftq45vd` (`email`),
  CONSTRAINT `FK97845ptm4fqko9i7n2ftq45vd` FOREIGN KEY (`email`) REFERENCES `user` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_profile`
--

LOCK TABLES `user_profile` WRITE;
/*!40000 ALTER TABLE `user_profile` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_profile` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-03-12 12:05:22
